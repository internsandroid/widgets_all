package com.example.ashwini.prjct122;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Second extends AppCompatActivity {
Button btn;
EditText edit,edit2;
TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        btn=(Button)findViewById(R.id.btn);
        edit=(EditText) findViewById(R.id.editText);
        edit2=(EditText) findViewById(R.id.ed2);
        text=(TextView) findViewById(R.id.textView);
       btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Integer answer=get_nd_display();
               text.setText(Integer.toString(answer));

           }
       });


    }
    public Integer get_nd_display()
    {
        String one=edit.getText().toString();
        String two=edit2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a+b;
        return c;


    }
}
