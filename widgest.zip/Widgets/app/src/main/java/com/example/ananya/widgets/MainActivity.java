package com.example.ananya.widgets;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.nio.InvalidMarkException;

import static com.example.ananya.widgets.R.id.imageView;

public class MainActivity extends AppCompatActivity {
    RelativeLayout lay;
    ToggleButton tg;
    CheckBox chk;
    TextView t1, t2, t3, t4;
    Switch sw;
    ImageView img;
    Animation anim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tg = (ToggleButton) findViewById(R.id.toggleButton);
        lay = (RelativeLayout) findViewById(R.id.layout);
        tg.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    lay.setBackgroundResource(R.drawable.h);
                } else {
                    lay.setBackgroundResource(R.drawable.b);
                }
            }
        });
        chk = (CheckBox) findViewById(R.id.checkBox);
        t1 = (TextView) findViewById(R.id.textView);
        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    t1.setText("Check box selected");

                } else {
                    t1.setText("  ");
                }
            }

        });
        RadioButton r1, r2;
        r1 = (RadioButton) findViewById(R.id.radioButton);
        r2 = (RadioButton) findViewById(R.id.radioButton2);
        t2 = (TextView) findViewById(R.id.textView2);
        RadioGroup rg;
        rg = (RadioGroup) findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton) {
                    t2.setText("Male");
                } else {
                    t2.setText("Female");
                }
            }
        });
        SeekBar sk;
        sk = (SeekBar) findViewById(R.id.seekBar);
        t3 = (TextView) findViewById(R.id.textView3);
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                t3.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sw = (Switch) findViewById(R.id.switch1);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    img = (ImageView) findViewById(R.id.imageView);
                    anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotation);
                    img.startAnimation(anim);
                }
                else
                {
                    img.getAnimation().cancel();
                    img.clearAnimation();
                }
            }

        });
    }
}

