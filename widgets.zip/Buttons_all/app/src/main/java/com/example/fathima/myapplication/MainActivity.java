package com.example.fathima.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton tog;
    RadioButton r1,r2;
    SeekBar seek;
    CheckBox check;
    Switch sw;
    TextView t1,t2,t3,t4;
    ImageView im;
    RelativeLayout layo;
    RadioGroup rg;
    Animation animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layo=(RelativeLayout)findViewById(R.id.layout);
        tog=(ToggleButton)findViewById(R.id.toggleButton);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
        seek=(SeekBar)findViewById(R.id.seekBar);
        check=(CheckBox)findViewById(R.id.checkBox);
        sw=(Switch)findViewById(R.id.switch1);
        t1=(TextView)findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.textView2);
        t3=(TextView)findViewById(R.id.textView3);
        t4=(TextView)findViewById(R.id.textView4);
        layo.setBackgroundResource(R.drawable.background2);

        tog.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    layo.setBackgroundResource(R.drawable.background1);
                }
                else
                {
                    layo.setBackgroundResource(R.drawable.background2);
                }
            }
        });

        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    t2.setText("Check box selected");
                }
                else
                {
                    t2.setText(" ");
                }
            }
        });

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.radioButton3)
                {
                    t3.setText("Male");
                }
                if(checkedId==R.id.radioButton4)
                {
                    t3.setText("Female");

                }
            }
        });

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                t4.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                im=(ImageView)findViewById(R.id.imageView);
                animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotation);
                if(isChecked){
                    im.startAnimation(animation);
                }
                else
                {
                    im.getAnimation().cancel();
                    im.clearAnimation();
                }
            }
        });
    }
}
