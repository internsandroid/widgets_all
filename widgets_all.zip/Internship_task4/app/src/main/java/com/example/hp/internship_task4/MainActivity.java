package com.example.hp.internship_task4;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    SeekBar seek;
    Switch switch1;
    RadioButton r1,r2;
    CheckBox check;
    ToggleButton toggle;
    TextView  text1,text2,text3,text4;
    ImageView image;
    RadioGroup rg;
RelativeLayout rel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seek=(SeekBar)findViewById(R.id.seek);
        switch1=(Switch)findViewById(R.id.switch1);
        rg=findViewById(R.id.rg);
        r1=(RadioButton)findViewById(R.id.r1);
        r2=(RadioButton)findViewById(R.id.r2);
        check=(CheckBox)findViewById(R.id.check);
        toggle=(ToggleButton)findViewById(R.id.toggle);
        text1=(TextView)findViewById(R.id.text1);
        text2=(TextView)findViewById(R.id.text2);
        text3=(TextView)findViewById(R.id.text3);
        text4=(TextView)findViewById(R.id.text4);
        image=(ImageView)findViewById(R.id.image);
        rel=findViewById(R.id.re);
      rel.setBackgroundColor(Color.RED);

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text4.setText("RED");
                if (toggle.isChecked()){
                   rel.setBackgroundColor(Color.BLUE);
                    text4.setText("BLUE");
                }
                else
                {
                    rel.setBackgroundColor(Color.RED);
                    text4.setText("RED");
                }
            }
        });
      switch1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation rotation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotaion);
                rotation.setRepeatCount(Animation.INFINITE);
                image.startAnimation(rotation);
            }
        });



        text2.setText("welcome");
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                text2.setTextSize(progress);
                Toast.makeText(getApplicationContext(),String.valueOf(progress), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.r1:
                        text1.setText("Male is selected");
                        break;
                    case R.id.r2:
                        text1.setText("Female is selected");
                        break;
                }
            }
        });
       check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check.isChecked())
                {
                    text3.setText("choose option");
                }
                else
                {
                    text3.setText("");
                }
            }
        });




    }
}
