package com.example.asha.background;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    TextView text,text2,text3,text4;
    ToggleButton toggle;
    RadioButton radio,radio2;
    CheckBox check;
    SeekBar seek;
    Switch sw;
    RelativeLayout relative;
    RadioGroup rg;
    int textSize,saveProgress;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (TextView) findViewById(R.id.textView);
        text2 = (TextView) findViewById(R.id.textView2);
        text3 = (TextView) findViewById(R.id.textView3);
        text4=(TextView)findViewById(R.id.textView4);
        toggle=(ToggleButton)findViewById(R.id.toggleButton);
        check=(CheckBox)findViewById(R.id.checkBox);
        seek=(SeekBar)findViewById(R.id.seekBar);
        sw=(Switch)findViewById(R.id.switch1);
        relative=(RelativeLayout) findViewById(R.id.relative);
        rg=(RadioGroup) findViewById(R.id.radioGroup);
        imageView=(ImageView) findViewById(R.id.imageView);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    relative.setBackgroundResource(R.drawable.images);
                    text.setText("Changed" +toggle.getText());
                }
                else {
                    relative.setBackgroundResource(R.drawable.ic_launcher_background);
                    text.setText("Unchanged" +toggle.getText());
                }
            }
        });
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                /*RadioButton checkedRadioButton=(RadioButton)group.findViewById(checkedId);
                boolean isChecked=checkedRadioButton.isChecked();
                if (isChecked)
                {
                    text2.setText("Checked:"+ checkedRadioButton.getText());
                }*/
                RadioButton radio=(RadioButton)findViewById(checkedId);
                RadioButton radio2=(RadioButton)findViewById(checkedId);
                text2.setText("You Selected:" +radio.getText());
                text2.setText("You Selected:" +radio2.getText());

            }
        });
       check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if(isChecked)
               {
                   text3.setText("Selected:" +check.getText());
               }
               else
               {
                   text3.setText("Unselected:" +check.getText());
               }
           }
       });
       seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
           @Override
           public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
               textSize = textSize + (progress-saveProgress);
               saveProgress = progress;
               text4.setTextSize(textSize);
           }

           @Override
           public void onStartTrackingTouch(SeekBar seekBar) {

           }

           @Override
           public void onStopTrackingTouch(SeekBar seekBar) {

           }
       });
       sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if(isChecked)
               {
                   ImageView animationTarget = (ImageView) findViewById(R.id.imageView);
                   Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.rotate);
                   animationTarget.startAnimation(animation);
               }
               else
               {
                   ImageView animationTarget = (ImageView) findViewById(R.id.imageView);
                    Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.rotate);
                    animationTarget.clearAnimation();
               }


           }
       });

    }
}
