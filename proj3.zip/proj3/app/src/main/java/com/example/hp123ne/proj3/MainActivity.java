package com.example.hp123ne.proj3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView Result;
EditText Input;
Button ASButton;

int i,j,temp,num[];
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ASButton = (Button) findViewById(R.id.button6);
        Input = (EditText) findViewById(R.id.editText);
        Result = (TextView) findViewById(R.id.TextView);

        ASButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BubbleSort();

            }
        });
    }
    public void BubbleSort() {
    Spannable spn = Input.getText();
    num = new int[spn.length()];
    int count = 0;
    for (int i = 0; i < spn.length(); i++) {
        if((spn.charAt(i)+"").matches(".*\\d.*")) {
            num[i] = Integer.parseInt("" + spn.charAt(i));
            count++;
        }
    }
    int temp = 0;
    for (int i=0; i<num.length-1; i++) {
        for (j=0; j<num.length-1;j++) {
            if (num[j] >num[j+1]) {
                temp = num[j];
                num[j] = num[j+1];
                num[j+1] = temp;

            }
        }
    }
    String result = "";
    for (int i = 0; i < num.length; i++) {
        result += num[i] + " ";

        }
        Result.setText(result);
    }
}
