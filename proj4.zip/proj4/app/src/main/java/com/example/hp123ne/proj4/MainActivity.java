package com.example.hp123ne.proj4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
   ToggleButton toggleButton;
    TextView textView,textView2,textView4,textView5;
    ImageView imageView;
    //EditText editText2;
    RadioGroup radioGroup;
    RadioButton RadioButton2;
    RadioButton RadioButton3;
    SeekBar seekBar;
    Switch switch1;
    RelativeLayout relativeLayout;
    CheckBox checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toggleButton = (ToggleButton) findViewById(R.id.toggleButton);
        textView = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView4 = (TextView) findViewById(R.id.textView4);
        textView5 = (TextView) findViewById(R.id.textView5);
        imageView = (ImageView) findViewById(R.id.imageView);
        //editText2 = (EditText) findViewById(R.id.editText2);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        RadioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        RadioButton3 = (RadioButton) findViewById(R.id.radioButton3);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        switch1 =  (Switch) findViewById(R.id.switch1);
        relativeLayout = (RelativeLayout) findViewById(R.id.relative);
        checkbox = (CheckBox) findViewById(R.id.checkBox);

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)
                    relativeLayout.setBackgroundResource(R.drawable.ic_launcher_background);

                else
                    relativeLayout.setBackgroundResource(R.drawable.ic_launcher_background);


        }

    });
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(checkbox.isChecked())
                {
                    textView2.setText("checkbox selected");

                }
            }
        });
        RadioButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(RadioButton2.getId() == R.id.radioButton2) {
                    textView5.setText("Female");
                }
            }
        });

        RadioButton3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (RadioButton3.getId() == R.id.radioButton3) {
                    textView5.setText("Male");
                }
            }
        });


    }

}