package com.example.admin.button_settings;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
ToggleButton to1;
CheckBox c1;
RadioGroup rg;
RadioButton r1,r2;
Switch s1;
SeekBar se1;
TextView t1,t2,t3,t4;
ImageView i1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        to1=(ToggleButton)findViewById(R.id.toggleButton);
        c1=(CheckBox)findViewById(R.id.checkBox);
        r1=(RadioButton)findViewById(R.id.radioButton);
        r2=(RadioButton)findViewById(R.id.radioButton2);
        s1=(Switch)findViewById(R.id.switch1);
        se1=(SeekBar)findViewById(R.id.seekBar2);
        t1=(TextView)findViewById(R.id.text1);
        t2=(TextView)findViewById(R.id.text2);
        t3=(TextView)findViewById(R.id.text3);
        t4=(TextView)findViewById(R.id.text4);
        i1=(ImageView)findViewById(R.id.imageView);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
        to1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                RelativeLayout lay=(RelativeLayout) findViewById(R.id.relative);
                if(isChecked){
                    lay.setBackgroundResource(R.drawable.layout);
                    int pic=R.drawable.layout;
                    lay.setBackgroundResource(pic);
                    t1.setText("Night mode in on");
                    Toast.makeText(getApplicationContext(),"Night mode on",Toast.LENGTH_SHORT).show();
                }
                else{
                    lay.setBackgroundResource(android.R.drawable.btn_default);
                    t1.setText("Night mode is off");
                    Toast.makeText(getApplicationContext(),"Night mode off",Toast.LENGTH_SHORT).show();
                }
            }
        });

c1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(isChecked){
            t2.setText("Checkbox is selected");
        }
        else
        {
            t2.setText("Checkbox is not selected");
        }
    }

});
rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        View radioButton=rg.findViewById(checkedId);
        int index=rg.indexOfChild(radioButton);
        switch (index){
            case 0:t3.setText("Male");
            break;
            case 1:t3.setText("Female");
            break;
        }
    }
});
se1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        t4.setTextSize(progress);
        Toast.makeText(getApplicationContext(),String.valueOf(progress),Toast.LENGTH_LONG).show();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {


    }
});
s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Animation myRotation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
        if (isChecked) {

            i1.startAnimation(myRotation);
        } else {
            i1.clearAnimation();
        }
    }
});

    }
}